<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'restaurant_db');
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Restaurant Management Dashboard</h2>
        <ul>
            <li><a href="users.php">Manage Users</a></li>
            <li><a href="menu.php">Manage Menu</a></li>
            <li><a href="orders.php">Manage Orders</a></li>
            <li><a href="reservations.php">Manage Reservations</a></li>
            <li><a href="tables.php">Manage Tables</a></li>
            <li><a href="payments.php">Manage Payments</a></li>
            <li><a href="admins.php">Manage Admins</a></li>
            <li><a href="reviews.php">Manage Reviews</a></li>
            <li><a href="images.php">Manage Images</a></li>
        </ul>
    </div>
</body>
</html>
