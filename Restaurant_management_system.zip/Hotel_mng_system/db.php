<?php
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "restaurant_db"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $table_number = $_POST['table_number'];
    $capacity = $_POST['capacity'];

    $sql = "INSERT INTO tables (table_number, capacity) VALUES ('$table_number', '$capacity')";

    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>Record inserted successfully</p>";
    } else {
        echo "<p style='color:red;'>Error: " . $conn->error . "</p>";
    }
}

$result = $conn->query("SELECT * FROM tables");

?>