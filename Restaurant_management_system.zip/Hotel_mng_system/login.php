<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <style type="text/css">
    /* General Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Arial', sans-serif;
      background: linear-gradient(135deg, #ff9a3e, #ff6a00);
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #333;
    }

    /* Login Container */
    .login-container {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
    }

    .login-box {
      background: #fff;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      width: 400px;
      text-align: center;
    }

    h2 {
      font-size: 2rem;
      color: #ff6a00;
      margin-bottom: 1.5rem;
    }

    /* Form Group */
    .form-group {
      margin-bottom: 1.5rem;
      text-align: left;
    }

    label {
      font-size: 0.9rem;
      color: #666;
    }

    input {
      width: 100%;
      padding: 0.8rem;
      font-size: 1rem;
      border: 1px solid #ccc;
      border-radius: 5px;
      margin-top: 0.3rem;
      transition: border-color 0.3s ease;
    }

    input:focus {
      outline: none;
      border-color: #ff6a00;
    }

    /* Login Button */
    .login-btn {
      background: #ff6a00;
      color: #fff;
      padding: 0.8rem;
      font-size: 1rem;
      border: none;
      border-radius: 5px;
      width: 100%;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .login-btn:hover {
      background: #ff3d00;
    }

    .register-link {
      margin-top: 1rem;
      font-size: 0.9rem;
    }

    .register-link a {
      color: #ff6a00;
      text-decoration: none;
      font-weight: bold;
    }

    .register-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <div class="login-box">
      <h2>Login</h2>
      <form action="authenticate.php" method="POST">
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" placeholder="Enter your username" required>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" placeholder="Enter your password" required>
        </div>
        <button type="submit" class="login-btn"><a href="menu.php">Login</a></button>
        <p class="register-link">Don't have an account? <a href="register.html">Sign up</a></p>
      </form>
    </div>
  </div>
</body>
</html>
