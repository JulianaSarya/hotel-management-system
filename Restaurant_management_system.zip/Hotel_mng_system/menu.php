<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Menu</title>
  <style>
    /* General Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Arial', sans-serif;
      background: #f8f8f8;
      color: #333;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    /* Navbar */
    .navbar {
      background-color: #fff;
      color: #ff6a00;
      display: flex;
      justify-content: space-between;
      padding: 1rem 2rem;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .navbar a {
      color: #ff6a00;
      text-decoration: none;
      font-size: 1rem;
      font-weight: bold;
      margin: 0 1rem;
    }

    .navbar a:hover {
      text-decoration: underline;
    }

    .navbar .nav-left {
      display: flex;
      align-items: center;
    }

    .navbar .nav-right {
      display: flex;
      align-items: center;
    }
    .menu-container {
      padding: 2rem;
      text-align: center;
    }

    h1 {
      color: #ff6a00;
      margin-bottom: 1rem;
    }

    .menu-items {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
      margin-top: 1rem;
    }

    .menu-item {
      background: #fff;
      padding: 1rem;
      border: 1px solid #ddd;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .menu-item:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    }

    .menu-item img {
      max-width: 100%;
      border-radius: 8px;
    }

    .menu-item h3 {
      color: #ff6a00;
      margin: 0.5rem 0;
    }

    .menu-item p {
      color: #666;
    }

    .menu-item button {
      background: #ff6a00;
      color: #fff;
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .menu-item button:hover {
      background: #ff3d00;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar">
    <div class="nav-left">
      <a href="index.html">Home</a>
      <a href="orders.html">Orders</a>
      <a href="Reservations.html">Reservation</a>
      <a href="Menu.html">Menu</a>
      <a href="dashboard.html">Dashboard</a>


    </div>
    <div class="nav-right">
      <a href="logout.php">Logout</a>
    </div>
  </nav>

  <div class="menu-container">
    <h1>Our Delicious Foods</h1>
    <div class="menu-items">
      <div class="menu-item">
        <img src="img/3.jpg" alt="Pilau">
        <h3>Pilau</h3>
        <p>pilau, kuku, kachumbari na Sharubati</p>
        <button>Order Now</button>
      </div>

      <div class="menu-item">
        <img src="img/2.jpg" alt="">chipsi
        <h3>Chipsi</h3>
        <p>chipsi, kuku na juisi(aina yoyote unayohitaji)</p>
        <button>Order Now</button>
      </div>

      <div class="menu-item">
        <img src="img/1.jpg" alt="Ugali">
        <h3>Ugali samaki</h3>
        <p>Ugali, samaki sato, mlenda, matembele na salad</p>
        <button>Order Now</button>
      </div>

      <div class="menu-item">
        <img src="img/4.jpg" alt="Salad">
        <h3>Salad</h3>
        <p>Juicy parachichi, kitunguu, nyanya, karoti, mayai</p>
        <button>Order Now</button>
      </div>

      <div class="menu-item">
        <img src="img/6.jpg" alt="Tambi">
        <h3>Tambi</h3>
        <p>Tambi, maini, sharubati ya parachichi</p>
        <button>Order Now</button>
      </div>

     <div class="menu-item">
        <img src="img/7.jpg" alt="Salad">
        <h3>Salad</h3>
        <p>Juicy parachicgi, kitunguu, nyanya, karoti, mayai</p>
        <button>Order Now</button>
      </div>

      <div class="menu-item">
        <img src="img/1.jpg" alt="Ugali">
        <h3>Ugali samaki</h3>
        <p>Ugali, samaki sato, mlenda, matembele na salad</p>
        <button>Order Now</button>
      </div>

      <div class="menu-item">
        <img src="img/2.jpg" alt="Ugali">
        <h3>Ugali samaki</h3>
        <p>Ugali, samaki sato, mlenda, matembele na salad</p>
        <button>Order Now</button>
      </div>

       <div class="menu-item">
        <img src="img/3.jpg" alt="Pilau">
        <h3>Pilau</h3>
        <p>pilau, kuku, kachumbari na Sharubati</p>
        <button>Order Now</button>
    </div>
    <div class="menu-item">
        <img src="img/6.jpg" alt="Pilau">
        <h3>Pilau</h3>
        <p>pilau, kuku, kachumbari na Sharubati</p>
        <button>Order Now</button>
  </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const orderItems = JSON.parse(localStorage.getItem('orderItems')) || [];

      document.querySelectorAll('.menu-item button').forEach(button => {
        button.addEventListener('click', (e) => {
          const menuItem = e.target.closest('.menu-item');
          const itemName = menuItem.getAttribute('data-item');
          const itemPrice = menuItem.getAttribute('data-price');

          const newOrder = { name: itemName, price: parseFloat(itemPrice) };
          orderItems.push(newOrder);

          localStorage.setItem('orderItems', JSON.stringify(orderItems));
          alert(`${itemName} added to order!`);
        });
      });
    });
  </script>
</html>
