<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Orders</title>
  <style>
    /* General Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Arial', sans-serif;
      background: #f8f8f8;
      color: #333;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    /* Navbar */
    .navbar {
      background: linear-gradient(135deg, #ff9a3e, #ff6a00);
      padding: 1rem;
      color: #fff;
      text-align: center;
      font-size: 1.5rem;
      font-weight: bold;
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .navbar a {
      color: #fff;
      text-decoration: none;
      margin: 0 1rem;
      font-size: 1rem;
    }

    .navbar a:hover {
      text-decoration: underline;
    }

    /* Main Content */
    .orders-container {
      padding: 2rem;
      text-align: center;
    }

    h1 {
      color: #ff6a00;
      margin-bottom: 1rem;
    }

    .order-item {
      background: #fff;
      padding: 1rem;
      border: 1px solid #ddd;
      border-radius: 8px;
      margin: 1rem 0;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .order-item img {
      max-width: 100px;
      border-radius: 8px;
    }

    .order-item h3 {
      color: #ff6a00;
      margin-left: 1rem;
    }

    .order-item p {
      color: #666;
    }

    .order-item button {
      background: #ff6a00;
      color: #fff;
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .order-item button:hover {
      background: #ff3d00;
    }

    .payment-btn {
      background: #4CAF50;
      color: #fff;
      padding: 0.8rem;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      margin-top: 2rem;
      transition: background-color 0.3s ease;
    }

    .payment-btn:hover {
      background: #45a049;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <div class="navbar">
    <a href="menu.html">Menu</a>
    <a href="logout.php">Logout</a>
  </div>

  <!-- Orders Content -->
  <div class="orders-container">
    <h1>Your Orders</h1>
    
    <!-- Example Order Item -->
    <div class="order-item">
      <img src="images/burger.jpg" alt="Burger">
      <div>
        <h3>Cheeseburger</h3>
        <p>Quantity: 1</p>
        <p>Price: $10.00</p>
      </div>
      <div>
        <button onclick="removeOrder()">Remove</button>
      </div>
    </div>

    <div class="order-item">
      <img src="images/pizza.jpg" alt="Pizza">
      <div>
        <h3>Margherita Pizza</h3>
        <p>Quantity: 2</p>
        <p>Price: $18.00</p>
      </div>
      <div>
        <button onclick="removeOrder()">Remove</button>
      </div>
    </div>

    <!-- More order items would be listed similarly -->

    <!-- Payment Button -->
    <button class="payment-btn" onclick="processPayment()">Proceed to Payment</button>
  </div>

  <script>
    function removeOrder() {
      alert('Order removed!');
      // Here you can implement AJAX or form submission to remove the order from the database.
    }

    function processPayment() {
      alert('Proceeding to payment...');
      // Here you can redirect to a payment gateway or process the payment.
    }
  </script>
</body>
</html>
