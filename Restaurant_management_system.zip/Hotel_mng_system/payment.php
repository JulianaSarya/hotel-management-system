<?php
// Database connection
$servername = "localhost";
$username = "root"; // your database username
$password = ""; // your database password
$dbname = "restaurant_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $user_id = $_POST['user_id'];
  $amount = $_POST['amount'];
  $payment_method = $_POST['payment_method'];
  $order_id = $_POST['order_id']; // assuming you have an order_id for the order being paid

  // Insert payment into database
  $sql = "INSERT INTO payments (user_id, amount, payment_method, order_id) VALUES ('$user_id', '$amount', '$payment_method', '$order_id')";

  if ($conn->query($sql) === TRUE) {
    echo "Payment successful!";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment</title>
  <style>
    /* Basic styling */
    body {
      font-family: Arial, sans-serif;
      background: #f8f8f8;
      color: #333;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .payment-form {
      background: #fff;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      width: 400px;
    }

    h2 {
      margin-bottom: 1rem;
    }

    label, input, select {
      width: 100%;
      margin-bottom: 1rem;
      padding: 0.8rem;
      font-size: 1rem;
      border: 1px solid #ddd;
      border-radius: 5px;
    }

    input[type="submit"] {
      background: #ff6a00;
      color: #fff;
      border: none;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background: #ff3d00;
    }
  </style>
</head>
<body>

  <div class="payment-form">
    <h2>Make a Payment</h2>
    <form action="payment.php" method="POST">
      <label for="user_id">User ID</label>
      <input type="text" id="user_id" name="user_id" required>

      <label for="amount">Amount</label>
      <input type="number" step="1000" id="amount" name="amount" required>

      <label for="payment_method">Payment Method</label>
      <select id="payment_method" name="payment_method" required>
        <option value="Credit Card">Credit Card</option>
        <option value="Debit Card">Debit Card</option>
        <option value="PayPal">PayPal</option>
        <option value="Cash">Cash</option>
      </select>

      <label for="order_id">Order ID</label>
      <input type="text" id="order_id" name="order_id" required>

      <input type="submit" value="Pay">
    </form>
  </div>

</body>
</html>
