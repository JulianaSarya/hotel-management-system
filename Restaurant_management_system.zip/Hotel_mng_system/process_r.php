<?php
// Database connection
$servername = "localhost";
$username = "root"; // your database username
$password = ""; // your database password
$dbname = "restaurant";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $guests = $_POST['guests'];
  $datetime = $_POST['datetime'];

  // Insert reservation into the database
  $sql = "INSERT INTO reservation (name, email, phone, guests, datetime) VALUES ('$name', '$email', '$phone', '$guests', '$datetime')";

  if ($conn->query($sql) === TRUE) {
    echo "Reservation made successfully!";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

$conn->close();
?>
