<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reservation</title>
  <style>
    /* General Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Arial', sans-serif;
      background: #f8f8f8;
      color: #333;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    /* Navbar */
    .navbar {
      background: linear-gradient(135deg, #ff9a3e, #ff6a00);
      padding: 1rem;
      color: #fff;
      text-align: center;
      font-size: 1.5rem;
      font-weight: bold;
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .navbar a {
      color: #fff;
      text-decoration: none;
      margin: 0 1rem;
      font-size: 1rem;
    }

    .navbar a:hover {
      text-decoration: underline;
    }

    /* Main Content */
    .reservation-container {
      padding: 2rem;
      text-align: center;
    }

    h1 {
      color: #ff6a00;
      margin-bottom: 1rem;
    }

    .reservation-form {
      background: #fff;
      padding: 2rem;
      border: 1px solid #ddd;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .form-group {
      margin-bottom: 1rem;
      width: 100%;
    }

    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      color: #666;
    }

    .form-group input,
    .form-group select {
      width: 100%;
      padding: 0.8rem;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 1rem;
    }

    .form-group button {
      background: #ff6a00;
      color: #fff;
      padding: 0.8rem 1.5rem;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .form-group button:hover {
      background: #ff3d00;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <div class="navbar">
    <a href="menu.html">Menu</a>
    <a href="orders.php">Orders</a>
    <a href="logout.php">Logout</a>
  </div>

  <!-- Reservation Content -->
  <div class="reservation-container">
    <h1>Make a Reservation</h1>

    <form action="process_r.php" method="POST" class="reservation-form">
      <div class="form-group">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" required>
      </div>

      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>
      </div>

      <div class="form-group">
        <label for="phone">Phone</label>
        <input type="tel" id="phone" name="phone" required>
      </div>

      <div class="form-group">
        <label for="guests">Number of Guests</label>
        <select id="guests" name="guests" required>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
        </select>
      </div>

      <div class="form-group">
        <label for="datetime">Reservation Date & Time</label>
        <input type="datetime-local" id="datetime" name="datetime" required>
      </div>

      <div class="form-group">
        <button type="submit">Make Reservation</button>
      </div>
    </form>
  </div>
</body>
</html>
