<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "restaurant_db"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $table_number = $_POST['table_number'];
    $capacity = $_POST['capacity'];

    $sql = "INSERT INTO tables (table_number, capacity) VALUES ('$table_number', '$capacity')";

    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>Record inserted successfully</p>";
    } else {
        echo "<p style='color:red;'>Error: " . $conn->error . "</p>";
    }
}

$result = $conn->query("SELECT * FROM tables");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Management</title>
    <style>
        table { width: 50%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 8px; text-align: center; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>

    <h2>Table Management</h2>
    
    <!-- Form to Insert Data -->
    <form method="POST">
        <label>Table Number:</label>
        <input type="text" name="table_number" required><br><br>

        <label>Capacity:</label>
        <input type="text" name="capacity" required><br><br>

        <button type="submit">Submit</button>
    </form>


    <h3>Stored Tables</h3>
    <table>
        <tr>
            <th>ID</th>
            <th>Table Number</th>
            <th>Capacity</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['table_number']}</td>
                        <td>{$row['capacity']}</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='3'>No records found</td></tr>";
        }
        ?>
    </table>

</body>
</html>

<?php
$conn->close();
?>
