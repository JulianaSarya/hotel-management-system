<?php
// Database connection
$servername = "localhost";
$username = "root"; // or your database username
$password = ""; // or your database password
$dbname = "restaurant_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Fetch tables
$tables_query = "SELECT * FROM tables";
$tables_result = $conn->query($tables_query);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tables</title>
  <style>
    /* General Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Arial', sans-serif;
      background: #f8f8f8;
      color: #333;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    /* Navbar */
    .navbar {
      background: linear-gradient(135deg, #ff9a3e, #ff6a00);
      padding: 1rem;
      color: #fff;
      text-align: center;
      font-size: 1.5rem;
      font-weight: bold;
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .navbar a {
      color: #fff;
      text-decoration: none;
      margin: 0 1rem;
      font-size: 1rem;
    }

    .navbar a:hover {
      text-decoration: underline;
    }

    /* Table Section */
    .table-container {
      padding: 2rem;
      display: flex;
      flex-direction: column;
    }

    h2 {
      color: #ff6a00;
      margin-bottom: 1rem;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    table, th, td {
      border: 1px solid #ddd;
    }

    th, td {
      padding: 0.8rem;
      text-align: left;
    }

    th {
      background: #ff9a3e;
      color: white;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <div class="navbar">
    <a href="dashboard.php">Dashboard</a>
    <a href="logout.php">Logout</a>
  </div>

  <!-- Tables Section -->
  <div class="table-container">
    <h2>Restaurant Tables</h2>
    <table>
      <tr>
        <th>Table ID</th>
        <th>Table Number</th>
        <th>Seats</th>
        <th>Status</th>
      </tr>
      <?php while($table = $tables_result->fetch_assoc()): ?>
        <tr>
          <td><?= $table['id'] ?></td>
          <td><?= $table['table_number'] ?></td>
          <td><?= $table['seats'] ?></td>
          <td><?= $table['status'] ?></td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

</body>
</html>
